import subdir.utils


def validate():
    return subdir.utils.foo()

