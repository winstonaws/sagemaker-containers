def foo():
    return 'return value from function in file in subdirectory'
